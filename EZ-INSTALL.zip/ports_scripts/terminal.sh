#!/bin/sh
echo "[*] Lancement de kmscon sur le TTY courant..."
exec kmscon
